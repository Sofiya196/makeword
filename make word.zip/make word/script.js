let totalLevelsCompleted = parseInt(localStorage.getItem("totalLevelsCompleted")) || 0;
    let currentThemeId = parseInt(localStorage.getItem("currentThemeId")) || 1;
    let currentLevel = parseInt(localStorage.getItem("currentLevel")) || 0;
    let isMusicOn = localStorage.getItem("music") === "true" || false;
    let isSoundOn = localStorage.getItem("sound") === "true" || true;
    let isVibrationOn = localStorage.getItem("vibration") === "true" || false;
    let highlightStyle = localStorage.getItem("highlightStyle") || "solid";
    let coins = parseInt(localStorage.getItem("coins")) || 100;

    const backgroundMusic = new Audio("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3");
    backgroundMusic.loop = true;
    const wordFoundSound = new Audio("https://www.myinstants.com/media/sounds/success.mp3");

    const highlightColors = [
        "#ff4d4d", "#4d79ff", "#33cc33", "#cc33cc", "#ff9933", "#ff66b3", "#33cccc"
    ];

    const validWords = [
        "WHEEL", "CHAIR", "APPLE", "PEAR", "KIWI", "PLUM", "LIME", "DATE", "FIG",
        "MANGO", "GRAPE", "LEMON", "BERRY", "PEACH", "APRICOT", "CHERRY", "ORANGE",
        "PAPAYA", "GUAVA", "LYCHEE", "TANGERINE", "COCONUT", "PINEAPPLE", "BANANA",
        "MELON", "QUINCE", "POMEGRAN", "NECTARINE", "BLUEBERRY", "RASPBERRY",
        "AVOCADO", "CRANBERRY", "CURRANT", "GOOSEBERRY", "KUMQUAT", "MANDARIN",
        "STARFRUIT", "DURIAN", "ELDERBERRY", "JACKFRUIT", "LOQUAT", "MULBERRY",
        "OLIVE", "PRUNE", "SOURCHERRY", "TAMARIND", "UGLI", "YUZU", "ACAI",
        "CLEMENTINE", "DRAGONFRU", "HAZELNUT", "MACADAMIA", "WALNUT", "ALMOND",
        "PISTACHIO", "PECAN", "CASHEW", "LION", "TIGER", "BEAR", "WOLF", "FOX",
        "DEER", "ELK", "ZEBRA", "HORSE", "CAMEL", "RHINO", "HIPPO", "GIRAFFE",
        "BUFFALO", "MONKEY", "GORILLA", "CHIMP", "BABOON", "ORANGUTAN", "LEOPARD",
        "JAGUAR", "EAGLE", "HAWK", "OWL", "FALCON", "VULTURE", "CONDOR", "OSPREY",
        "SNAKE", "CROCODILE", "ALLIGATOR", "LIZARD", "TURTLE", "TORTOISE", "PYTHON",
        "SHARK", "WHALE", "DOLPHIN", "SEAL", "WALRUS", "OTTER", "MANATEE", "PENGUIN",
        "ALBATROSS", "SEAGULL", "PELICAN", "CORMORANT", "HERON", "STORK", "SPARROW",
        "ROBIN", "CARDINAL", "BLUEJAY", "FINCH", "THRUSH", "WARBLER", "RIVER", "LAKE",
        "OCEAN", "STREAM", "POND", "CREEK", "BAY", "FOREST", "JUNGLE", "WOODLAND",
        "GROVE", "THICKET", "MEADOW", "PLAIN", "MOUNTAIN", "HILL", "VALLEY", "CANYON",
        "RIDGE", "PEAK", "CLIFF", "DESERT", "TUNDRA", "SAVANNA", "PRAIRIE", "STEPPE",
        "MARSH", "SWAMP", "TREE", "BUSH", "SHRUB", "VINE", "FERN", "MOSS", "CACTUS",
        "FLOWER", "PETAL", "STEM", "LEAF", "ROOT", "BUD", "BLOOM", "SKY", "CLOUD",
        "RAIN", "SNOW", "WIND", "STORM", "FOG", "SUN", "MOON", "STAR", "COMET",
        "PLANET", "GALAXY", "NEBULA"
    ];

    const puzzles = [
        {
            id: 1,
            theme: "Fruits",
            icon: "https://img.icons8.com/color/50/000000/apple.png",
            unlocked: true,
            progress: parseInt(localStorage.getItem("progress_theme_1")) || 0,
            levels: [
                { words: ["APPLE", "PEAR", "KIWI", "PLUM", "LIME", "DATE", "FIG"] },
                { words: ["MANGO", "GRAPE", "LEMON", "BERRY", "PEACH", "APRICOT", "CHERRY"] },
                { words: ["ORANGE", "PAPAYA", "GUAVA", "LYCHEE", "TANGERINE", "COCONUT", "PINEAPPLE"] },
                { words: ["BANANA", "MELON", "QUINCE", "POMEGRAN", "NECTARINE", "BLUEBERRY", "RASPBERRY"] },
                { words: ["AVOCADO", "CRANBERRY", "CURRANT", "GOOSEBERRY", "KUMQUAT", "MANDARIN", "STARFRUIT"] },
                { words: ["DURIAN", "ELDERBERRY", "JACKFRUIT", "LOQUAT", "MULBERRY", "OLIVE", "PRUNE"] },
                { words: ["SOURCHERRY", "TAMARIND", "UGLI", "YUZU", "ACAI", "CLEMENTINE", "DRAGONFRU"] },
                { words: ["WHEELCHAIR", "MACADAMIA", "WALNUT", "ALMOND", "PISTACHIO", "PECAN", "CASHEW"] }
            ]
        },
        {
            id: 2,
            theme: "Animals",
            icon: "https://img.icons8.com/color/50/000000/lion.png",
            unlocked: totalLevelsCompleted >= 8,
            progress: parseInt(localStorage.getItem("progress_theme_2")) || 0,
            levels: [
                { words: ["LION", "TIGER", "BEAR", "WOLF", "FOX", "DEER", "ELK"] },
                { words: ["ZEBRA", "HORSE", "CAMEL", "RHINO", "HIPPO", "GIRAFFE", "BUFFALO"] },
                { words: ["MONKEY", "GORILLA", "CHIMP", "BABOON", "ORANGUTAN", "LEOPARD", "JAGUAR"] },
                { words: ["EAGLE", "HAWK", "OWL", "FALCON", "VULTURE", "CONDOR", "OSPREY"] },
                { words: ["SNAKE", "CROCODILE", "ALLIGATOR", "LIZARD", "TURTLE", "TORTOISE", "PYTHON"] },
                { words: ["SHARK", "WHALE", "DOLPHIN", "SEAL", "WALRUS", "OTTER", "MANATEE"] },
                { words: ["PENGUIN", "ALBATROSS", "SEAGULL", "PELICAN", "CORMORANT", "HERON", "STORK"] },
                { words: ["SPARROW", "ROBIN", "CARDINAL", "BLUEJAY", "FINCH", "THRUSH", "WARBLER"] }
            ]
        },
        {
            id: 3,
            theme: "Nature",
            icon: "https://img.icons8.com/color/50/000000/forest.png",
            unlocked: totalLevelsCompleted >= 8,
            progress: parseInt(localStorage.getItem("progress_theme_3")) || 0,
            levels: [
                { words: ["RIVER", "LAKE", "OCEAN", "STREAM", "POND", "CREEK", "BAY"] },
                { words: ["FOREST", "JUNGLE", "WOODLAND", "GROVE", "THICKET", "MEADOW", "PLAIN"] },
                { words: ["MOUNTAIN", "HILL", "VALLEY", "CANYON", "RIDGE", "PEAK", "CLIFF"] },
                { words: ["DESERT", "TUNDRA", "SAVANNA", "PRAIRIE", "STEPPE", "MARSH", "SWAMP"] },
                { words: ["TREE", "BUSH", "SHRUB", "VINE", "FERN", "MOSS", "CACTUS"] },
                { words: ["FLOWER", "PETAL", "STEM", "LEAF", "ROOT", "BUD", "BLOOM"] },
                { words: ["SKY", "CLOUD", "RAIN", "SNOW", "WIND", "STORM", "FOG"] },
                { words: ["SUN", "MOON", "STAR", "COMET", "PLANET", "GALAXY", "NEBULA"] }
            ]
        },
        {
            id: 4,
            theme: "Indoor Sports",
            icon: "assets/chess.png",
            unlocked: totalLevelsCompleted >= 8,
            progress: parseInt(localStorage.getItem("progress_theme_4")) || 0,
            levels: [
                { words: ["BADMINTON", "TABLETENNIS", "BASKETBALL", "VOLLEYBALL", "BOXING", "GYMNASTICS"] },
                { words: ["SQUASH", "BOWLING", "HANDBALL", "WRESTLING", "FENCING", "KARATE"] }
            ]
        },
        {
            id: 5,
            theme: "Outdoor Sports",
            icon: "https://img.icons8.com/color/50/000000/basketball.png",
            unlocked: totalLevelsCompleted >= 2,
            progress: parseInt(localStorage.getItem("progress_theme_5")) || 0,
            levels: [
                { words: ["SOCCER", "CRICKET", "BASEBALL", "RUGBY", "HOCKEY", "GOLF"] },
                { words: ["CYCLING", "ARCHERY", "ATHLETICS", "HORSEPOLO", "FRISBEE", "LACROSSE"] }
            ]
        },
        {
            id: 6,
            theme: "Water Sports",
            icon: "https://via.placeholder.com/50?text=Water",
            unlocked: totalLevelsCompleted >= 2,
            progress: parseInt(localStorage.getItem("progress_theme_6")) || 0,
            levels: [
                { words: ["SWIMMING", "SURFING", "ROWING", "DIVING", "KAYAKING", "WATERPOLO"] },
                { words: ["SAILING", "JETSKI", "SNORKELING", "CANOEING"] }
            ]
        },
        {
            id: 7,
            theme: "Olympic Sports",
            icon: "https://via.placeholder.com/50?text=Olympics",
            unlocked: totalLevelsCompleted >= 2,
            progress: parseInt(localStorage.getItem("progress_theme_7")) || 0,
            levels: [
                { words: ["ARCHERY", "FENCING", "JUDO", "WRESTLING", "TRIATHLON"] },
                { words: ["GYMNASTICS", "DIVING", "SPRINTING", "MARATHON", "SHOTPUT", "TAEKWONDO"] }
            ]
        },
        {
            id: 8,
            theme: "Extreme Sports",
            icon: "https://via.placeholder.com/50?text=Extreme",
            unlocked: totalLevelsCompleted >= 2,
            progress: parseInt(localStorage.getItem("progress_theme_8")) || 0,
            levels: [
                { words: ["BOBSLEIGH", "LUGE", "CLIMBING"] },
                { words: ["PARKOUR", "BMX", "MOTOCROSS", "SKYDIVING"] }
            ]
        },
        {
            id: 9,
            theme: "Flowers",
            icon: "https://via.placeholder.com/50?text=Flowers",
            unlocked: totalLevelsCompleted >= 2,
            progress: parseInt(localStorage.getItem("progress_theme_9")) || 0,
            levels: [
                { words: ["ROSE", "LILY", "TULIP", "DAISY", "ORCHID", "LOTUS"] },
                { words: ["JASMINE", "SUNFLOWER", "DAFFODIL", "HIBISCUS", "MARIGOLD", "LAVENDER"] },
                { words: ["CARNATION", "IRIS", "PEONY", "ZINNIA", "ASTER"] }
            ]
        },
        {
            id: 10,
            theme: "Houseplants",
            icon: "https://via.placeholder.com/50?text=Plants",
            unlocked: totalLevelsCompleted >= 3,
            progress: parseInt(localStorage.getItem("progress_theme_10")) || 0,
            levels: [
                { words: ["FERN", "POTHOS", "SNAKEPLANT", "ALOEVERA", "CACTUS"] },
                { words: ["BAMBOO", "FICUS", "ZZPLANT", "PEACELILY", "MONSTERA"] }
            ]
        },
        {
            id: 11,
            theme: "Herbs",
            icon: "https://via.placeholder.com/50?text=Herbs",
            unlocked: totalLevelsCompleted >= 2,
            progress: parseInt(localStorage.getItem("progress_theme_11")) || 0,
            levels: [
                { words: ["BASIL", "MINT", "THYME", "ROSEMARY", "OREGANO", "PARSLEY"] },
                { words: ["CHIVES", "CILANTRO", "DILL", "LEMONGRASS", "SAGE", "LAVENDER"] }
            ]
        },
        {
            id: 12,
            theme: "Indoor Things",
            icon: "https://via.placeholder.com/50?text=Indoor",
            unlocked: totalLevelsCompleted >= 2,
            progress: parseInt(localStorage.getItem("progress_theme_12")) || 0,
            levels: [
                { words: ["SOFA", "BED", "CHAIR", "TABLE", "DESK", "SHELF"] },
                { words: ["TV", "LAPTOP", "FRIDGE", "MICROWAVE", "FAN", "LAMP"] },
                { words: ["PLATE", "SPOON", "PAN", "TOWEL", "SOAP", "BRUSH"] },
                { words: ["CLOCK", "CURTAIN", "RUG", "BOOK", "PEN", "VASE"] }
            ]
        },
        {
            id: 13,
            theme: "Bedroom",
            icon: "https://via.placeholder.com/50?text=Bedroom",
            unlocked: totalLevelsCompleted >= 4,
            progress: parseInt(localStorage.getItem("progress_theme_13")) || 0,
            levels: [
                { words: ["BED", "PILLOW", "MATTRESS", "BLANKET", "WARDROBE", "CHAIR"] },
                { words: ["DRAWER", "MIRROR", "CLOSET", "CARPET", "RUG", "CURTAIN"] },
                { words: ["LAMP", "ALARM", "TV", "REMOTE", "FAN", "CHARGER"] },
                { words: ["BOOK", "DIARY", "HEADPHONES", "CUSHION", "CLOTHES", "BASKET"] }
            ]
        },
        {
            id: 14,
            theme: "College",
            icon: "images/apple.jpg",
            unlocked: totalLevelsCompleted >= 4,
            progress: parseInt(localStorage.getItem("progress_theme_14")) || 0,
            levels: [
                { words: ["DESK", "CHAIR", "WHITEBOARD", "PAPER", "PENCIL", "BOOK"] },
                { words: ["LIBRARY", "CAFETERIA", "GYM", "CANTEEN", "LAB", "STADIUM"] },
                { words: ["LECTURE", "STUDYGROUP", "GRADES", "EXAM", "ASSIGNMENT", "COURSE"] },
                { words: ["CLUB", "FESTIVAL", "PARTY", "FRIENDS", "WORKSHOP", "SOCIAL"] }
            ]
        }
    ];

    function updateCoins() {
        document.getElementById("coin-btn").innerHTML = `${coins} <i class="fas fa-search"></i>`;
        document.getElementById("coins").textContent = coins;
        localStorage.setItem("coins", coins);
    }

    function updateAudioButtons() {
        const musicBtn = document.getElementById("music-btn");
        const soundBtn = document.getElementById("sound-btn");
        const vibrationBtn = document.getElementById("vibration-btn");
        const pauseMusicBtn = document.getElementById("pause-music-btn");
        const pauseSoundBtn = document.getElementById("pause-sound-btn");
        const pauseVibrationBtn = document.getElementById("pause-vibration-btn");

        [musicBtn, pauseMusicBtn].forEach(btn => {
            if (btn) {
                btn.innerHTML = `<span class="icon">${isMusicOn ? "🎵" : "🔇"}</span> Music`;
                btn.classList.toggle("on", isMusicOn);
            }
        });
        [soundBtn, pauseSoundBtn].forEach(btn => {
            if (btn) {
                btn.innerHTML = `<span class="icon">${isSoundOn ? "🔊" : "🔇"}</span> Sound`;
                btn.classList.toggle("on", isSoundOn);
            }
        });
        [vibrationBtn, pauseVibrationBtn].forEach(btn => {
            if (btn) {
                btn.innerHTML = `<span class="icon">${isVibrationOn ? "📳" : "🚫"}</span> Vibration`;
                btn.classList.toggle("on", isVibrationOn);
            }
        });
    }

    function toggleMusic() {
        isMusicOn = !isMusicOn;
        localStorage.setItem("music", isMusicOn);
        if (isMusicOn) backgroundMusic.play().catch(() => console.log("Music blocked"));
        else backgroundMusic.pause();
        updateAudioButtons();
    }

    function toggleSound() {
        isSoundOn = !isSoundOn;
        localStorage.setItem("sound", isSoundOn);
        updateAudioButtons();
    }

    function toggleVibration() {
        isVibrationOn = !isVibrationOn;
        localStorage.setItem("vibration", isVibrationOn);
        if (isVibrationOn && "vibrate" in navigator) navigator.vibrate(200);
        updateAudioButtons();
    }

    function createPuzzleCard(puzzle) {
        const card = document.createElement("div");
        card.className = `puzzle-card ${puzzle.unlocked ? "unlocked" : "locked"}`;

        if (puzzle.unlocked && puzzle.progress === 100) {
            const crown = document.createElement("i");
            crown.className = "fas fa-crown crown";
            card.appendChild(crown);
        }

        const img = document.createElement("img");
        img.src = puzzle.icon;
        img.alt = puzzle.theme;
        card.appendChild(img);

        const name = document.createElement("p");
        name.textContent = puzzle.theme;
        card.appendChild(name);

        if (puzzle.unlocked) {
            const progress = document.createElement("progress");
            progress.value = puzzle.progress;
            progress.max = 100;
            card.appendChild(progress);

            const playBtn = document.createElement("button");
            playBtn.textContent = "Play";
            playBtn.className = "play-btn";
            playBtn.addEventListener("click", () => startGame(puzzle));
            card.appendChild(playBtn);
        } else {
            const lock = document.createElement("div");
            lock.className = "lock";
            lock.innerHTML = '<i class="fas fa-lock"></i>';
            card.appendChild(lock);
        }

        return card;
    }

    function startGame(puzzle) {
        try {
            currentThemeId = puzzle.id;
            const levelsCompleted = Math.floor((puzzle.progress / 100) * puzzle.levels.length);
            currentLevel = puzzle.id === parseInt(localStorage.getItem("currentThemeId"))
                ? parseInt(localStorage.getItem("currentLevel")) || Math.min(levelsCompleted, puzzle.levels.length - 1)
                : Math.min(levelsCompleted, puzzle.levels.length - 1);
            if (currentLevel < 0) currentLevel = 0;

            localStorage.setItem("currentThemeId", currentThemeId);
            localStorage.setItem("currentLevel", currentLevel);
            const homePage = document.getElementById("home-page");
            const gameContainer = document.getElementById("game-container");
            const gameTitle = document.getElementById("game-title");

            gameTitle.textContent = `${puzzle.theme} - Level ${currentLevel + 1}`;
            initGame(puzzle.levels[currentLevel].words);

            homePage.style.display = "none";
            gameContainer.style.display = "flex";
        } catch (e) {
            console.error("Error in startGame:", e);
        }
    }

    function initGame(words) {
        try {
            let grid = [];
            let selectedCells = [];
            let foundWords = {};
            let isSelecting = false;
            let lastTouchTime = 0;
            let dragDirection = null;

            const gridElement = document.getElementById("game-grid");
            gridElement.replaceWith(gridElement.cloneNode(false));
            document.getElementById("game-grid").id = "game-grid";
            const highlightBox = document.getElementById("highlight-box");
            if (highlightBox) highlightBox.remove();

            generateGrid();
            populateWordList();
            updateCoins();
            setupEventListeners();
            updateAudioButtons();
            if (isMusicOn) backgroundMusic.play().catch(() => console.log("Music blocked"));

            function generateGrid() {
                const gridElement = document.getElementById("game-grid");
                gridElement.innerHTML = "";
                grid = Array(9).fill().map(() => Array(10).fill(""));

                const validPositions = words.map(word => {
                    const positions = [];
                    for (let row = 0; row < 9; row++) {
                        for (let col = 0; col < 10; col++) {
                            if (canStartAt(word, row, col, 0)) positions.push({ row, col, dir: 0 });
                            if (canStartAt(word, row, col, 1)) positions.push({ row, col, dir: 1 });
                            if (canStartAt(word, row, col, 2)) positions.push({ row, col, dir: 2 });
                        }
                    }
                    return positions;
                });

                let maxAttempts = 15;
                for (let i = 0; i < words.length; i++) {
                    const word = words[i];
                    let positions = validPositions[i];
                    let placed = false;

                    positions = positions.sort(() => Math.random() - 0.5);

                    for (const pos of positions) {
                        if (placeWord(word, pos.row, pos.col, pos.dir)) {
                            placed = true;
                            break;
                        }
                        if (--maxAttempts <= 0) {
                            grid = Array(9).fill().map(() => Array(10).fill(""));
                            i = -1;
                            break;
                        }
                    }

                    if (!placed && maxAttempts > 0) {
                        let row, col, dir;
                        let attempts = 5;
                        do {
                            row = Math.floor(Math.random() * 9);
                            col = Math.floor(Math.random() * 10);
                            dir = Math.floor(Math.random() * 3);
                            if (--attempts <= 0) break;
                        } while (!canPlaceWord(word, row, col, dir));
                        if (attempts > 0) {
                            placeWord(word, row, col, dir);
                        }
                    }
                }

                for (let i = 0; i < 9; i++) {
                    for (let j = 0; j < 10; j++) {
                        if (!grid[i][j]) grid[i][j] = String.fromCharCode(65 + Math.floor(Math.random() * 26));
                        const cell = document.createElement("span");
                        cell.textContent = grid[i][j];
                        cell.setAttribute("data-letter", grid[i][j]);
                        cell.setAttribute("data-row", i);
                        cell.setAttribute("data-col", j);
                        gridElement.appendChild(cell);
                    }
                }
            }

            function canStartAt(word, row, col, direction) {
                const len = word.length;
                return (direction === 0 && col + len <= 10) ||
                       (direction === 1 && row + len <= 9) ||
                       (direction === 2 && row + len <= 9 && col + len <= 10);
            }

            function canPlaceWord(word, row, col, direction) {
    const len = word.length;
    if (direction === 0) {
        if (col + len > 10) return false;
        for (let i = 0; i < len; i++) 
            if (grid[row][col + i] && grid[row][col + i] !== word[i]) return false;
    } else if (direction === 1) {
        if (row + len > 9) return false;
        for (let i = 0; i < len; i++) 
            if (grid[row + i][col] && grid[row + i][col] !== word[i]) return false;
    } else {
        if (row + len > 9 || col + len > 10) return false;
        for (let i = 0; i < len; i++) 
            if (grid[row + i][col + i] && grid[row + i][col + i] !== word[i]) return false;
    }
    return true;
}

function placeWord(word, row, col, direction) {
    const len = word.length;

    // Diagonal placement chance: 60%
    if (direction === 2) {
        const randomChance = Math.random(); // 0 to 1
        if (randomChance > 0.6) return false;
    }

    if (!canPlaceWord(word, row, col, direction)) return false;

    if (direction === 0) {
        for (let i = 0; i < len; i++) grid[row][col + i] = word[i];
    } else if (direction === 1) {
        for (let i = 0; i < len; i++) grid[row + i][col] = word[i];
    } else {
        for (let i = 0; i < len; i++) grid[row + i][col + i] = word[i];
    }

    return true;
}




            function populateWordList() {
                const wordList = document.getElementById("word-list");
                wordList.innerHTML = "";
                words.forEach(word => {
                    const span = document.createElement("span");
                    span.textContent = word;
                    if (word in foundWords) {
                        span.classList.add("found");
                        span.style.color = foundWords[word];
                        span.style.textDecorationColor = foundWords[word];
                    }
                    wordList.appendChild(span);
                });
            }

            function setupEventListeners() {
                const gridElement = document.getElementById("game-grid");
                const newGridElement = gridElement.cloneNode(true);
                gridElement.replaceWith(newGridElement);

                newGridElement.addEventListener("mousedown", startSelection);
                document.addEventListener("mousemove", continueSelection);
                document.addEventListener("mouseup", endSelection);

                newGridElement.addEventListener("touchstart", startSelection, { passive: false });
                newGridElement.addEventListener("touchmove", continueSelection, { passive: false });
                newGridElement.addEventListener("touchend", endSelection, { passive: false });

                document.querySelector(".pause-btn").replaceWith(document.querySelector(".pause-btn").cloneNode(true));
                document.querySelector(".pause-btn").addEventListener("click", () => {
                    document.getElementById("pause-modal").classList.add("active");
                    if (isMusicOn) backgroundMusic.pause();
                    if (isVibrationOn && "vibrate" in navigator) navigator.vibrate(100);
                });

                const pauseModal = document.getElementById("pause-modal");
                pauseModal.replaceWith(pauseModal.cloneNode(true));
                document.getElementById("pause-modal").addEventListener("click", (e) => {
                    const modal = document.getElementById("pause-modal");
                    if (e.target.classList.contains("close-btn") || e.target.classList.contains("continue-btn")) {
                        modal.classList.remove("active");
                        if (isMusicOn) backgroundMusic.play().catch(() => console.log("Music blocked"));
                    } else if (e.target.id === "pause-music-btn") {
                        toggleMusic();
                    } else if (e.target.id === "pause-sound-btn") {
                        toggleSound();
                    } else if (e.target.id === "pause-vibration-btn") {
                        toggleVibration();
                    } else if (e.target.classList.contains("exit-btn")) {
                        modal.classList.remove("active");
                        localStorage.setItem("currentThemeId", currentThemeId);
                        localStorage.setItem("currentLevel", currentLevel);
                        document.getElementById("home-page").style.display = "block";
                        document.getElementById("game-container").style.display = "none";
                        updatePuzzleGrid();
                    }
                });

                document.getElementById("hint-btn").replaceWith(document.getElementById("hint-btn").cloneNode(true));
                document.getElementById("hint-btn").addEventListener("click", giveHint);

                document.getElementById("reset-btn").replaceWith(document.getElementById("reset-btn").cloneNode(true));
                document.getElementById("reset-btn").addEventListener("click", resetGame);

                document.getElementById("check-btn").replaceWith(document.getElementById("check-btn").cloneNode(true));
                document.getElementById("check-btn").addEventListener("click", checkSolution);
            }

            function startSelection(e) {
                e.preventDefault();
                isSelecting = true;
                selectedCells = [];
                dragDirection = null;
                const cell = e.target.closest("span");
                if (cell && Date.now() - lastTouchTime > 200) {
                    selectCell(cell);
                    lastTouchTime = Date.now();
                    console.log("Selection started at:", cell.dataset.row, cell.dataset.col);
                }
            }

            function continueSelection(e) {
                if (!isSelecting) return;
                e.preventDefault();
                const touch = e.touches ? e.touches[0] : e;
                const cell = document.elementFromPoint(touch.clientX, touch.clientY).closest("span");
                if (cell && !selectedCells.includes(cell) && Date.now() - lastTouchTime > 50) {
                    if (dragDirection && selectedCells.length > 1) {
                        const lastCell = selectedCells[selectedCells.length - 1];
                        const row1 = parseInt(lastCell.dataset.row);
                        const col1 = parseInt(lastCell.dataset.col);
                        const expectedRow = row1 + dragDirection.dr;
                        const expectedCol = col1 + dragDirection.dc;
                        if (
                            parseInt(cell.dataset.row) === expectedRow &&
                            parseInt(cell.dataset.col) === expectedCol
                        ) {
                            selectCell(cell);
                            lastTouchTime = Date.now();
                            console.log("Selected cell:", cell.dataset.row, cell.dataset.col);
                        }
                    } else {
                        selectCell(cell);
                        lastTouchTime = Date.now();
                        console.log("Selected cell:", cell.dataset.row, cell.dataset.col);
                    }
                }
            }

            function endSelection() {
                if (!isSelecting) return;
                isSelecting = false;
                checkSelectedWord();
                selectedCells.forEach(cell => cell.classList.remove("selected"));
                selectedCells = [];
                dragDirection = null;
                console.log("Selection ended");
            }

            function selectCell(cell) {
                if (selectedCells.length === 0) {
                    selectedCells.push(cell);
                    cell.classList.add("selected");
                } else if (selectedCells.length === 1) {
                    const lastCell = selectedCells[selectedCells.length - 1];
                    const row1 = parseInt(lastCell.dataset.row);
                    const col1 = parseInt(lastCell.dataset.col);
                    const row2 = parseInt(cell.dataset.row);
                    const col2 = parseInt(cell.dataset.col);
                    const dr = row2 - row1;
                    const dc = col2 - col1;
                    if (
                        (dr === 0 && Math.abs(dc) === 1) || // Horizontal
                        (dc === 0 && Math.abs(dr) === 1) || // Vertical
                        (Math.abs(dr) === 1 && Math.abs(dc) === 1) // Diagonal
                    ) {
                        selectedCells.push(cell);
                        cell.classList.add("selected");
                        dragDirection = { dr, dc };
                        console.log("Direction locked:", dragDirection);
                    }
                } else {
                    const lastCell = selectedCells[selectedCells.length - 1];
                    const row1 = parseInt(lastCell.dataset.row);
                    const col1 = parseInt(lastCell.dataset.col);
                    const row2 = parseInt(cell.dataset.row);
                    const col2 = parseInt(cell.dataset.col);
                    const dr = row2 - row1;
                    const dc = col2 - col1;
                    if (
                        dragDirection &&
                        (
                            (dragDirection.dr === 0 && dr === 0 && dc === dragDirection.dc) || // Horizontal
                            (dragDirection.dc === 0 && dc === 0 && dr === dragDirection.dr) || // Vertical
                            (dragDirection.dr !== 0 && dragDirection.dc !== 0 && dr === dragDirection.dr && dc === dragDirection.dc) // Diagonal
                        )
                    ) {
                        selectedCells.push(cell);
                        cell.classList.add("selected");
                    }
                }
            }

            function checkSelectedWord() {
                const word = selectedCells.map(cell => cell.dataset.letter).join("");
                const reverseWord = word.split("").reverse().join("");
                let foundWord = null;

                if (words.includes(word)) foundWord = word;
                else if (words.includes(reverseWord)) foundWord = reverseWord;

                if (foundWord && !(foundWord in foundWords)) {
                    const colorIndex = Object.keys(foundWords).length % highlightColors.length;
                    const color = highlightColors[colorIndex];
                    foundWords[foundWord] = color;
                    selectedCells.forEach(cell => {
                        cell.classList.add("found");
                        cell.style.backgroundColor = color;
                    });
                    coins += 5;
                    updateCoins();
                    populateWordList();
                    if (isSoundOn) wordFoundSound.play().catch(() => console.log("Sound blocked"));
                    if (isVibrationOn && "vibrate" in navigator) navigator.vibrate(100);
                    triggerBorderSparkles();
                    if (Object.keys(foundWords).length === words.length) advanceToNextLevel();
                } else {
                    let isValidSubstring = false;
                    for (const levelWord of words) {
                        if (levelWord.includes(word) || levelWord.includes(reverseWord)) {
                            if (validWords.includes(word) || validWords.includes(reverseWord)) {
                                isValidSubstring = true;
                                break;
                            }
                        }
                    }
                    if (isValidSubstring) {
                        coins += 5;
                        updateCoins();
                        if (isSoundOn) wordFoundSound.play().catch(() => console.log("Sound blocked"));
                        if (isVibrationOn && "vibrate" in navigator) navigator.vibrate(100);
                        triggerBorderSparkles();
                    }
                }
                selectedCells.forEach(cell => cell.classList.remove("selected"));
                selectedCells = [];
            }

            function triggerBorderSparkles() {
                const gridContainer = document.querySelector(".game-grid-container");
                gridContainer.classList.add("sparkle");
                setTimeout(() => gridContainer.classList.remove("sparkle"), 1000);

                const duration = 1000;
                const end = Date.now() + duration;

                (function frame() {
                    confetti({
                        particleCount: 2,
                        spread: 60,
                        startVelocity: 20,
                        angle: 90,
                        origin: { x: Math.random(), y: 0 },
                        colors: ["#ffd700", "#ffffff", "#ffeb3b"],
                        shapes: ["star", "circle"],
                        scalar: 0.5
                    });

                    confetti({
                        particleCount: 2,
                        spread: 60,
                        startVelocity: 20,
                        angle: 270,
                        origin: { x: Math.random(), y: 1 },
                        colors: ["#ffd700", "#ffffff", "#ffeb3b"],
                        shapes: ["star", "circle"],
                        scalar: 0.5
                    });

                    confetti({
                        particleCount: 2,
                        spread: 60,
                        startVelocity: 20,
                        angle: 0,
                        origin: { x: 0, y: Math.random() },
                        colors: ["#ffd700", "#ffffff", "#ffeb3b"],
                        shapes: ["star", "circle"],
                        scalar: 0.5
                    });

                    confetti({
                        particleCount: 2,
                        spread: 60,
                        startVelocity: 20,
                        angle: 180,
                        origin: { x: 1, y: Math.random() },
                        colors: ["#ffd700", "#ffffff", "#ffeb3b"],
                        shapes: ["star", "circle"],
                        scalar: 0.5
                    });

                    if (Date.now() < end) {
                        requestAnimationFrame(frame);
                    }
                })();
            }

            function giveHint() {
                if (coins < 50) {
                    alert("Not enough coins for a hint!");
                    return;
                }
                coins -= 50;
                updateCoins();
                const remainingWords = words.filter(word => !(word in foundWords));
                if (remainingWords.length === 0) return;
                const word = remainingWords[Math.floor(Math.random() * remainingWords.length)];

                for (let row = 0; row < 9; row++) {
                    for (let col = 0; col < 10; col++) {
                        if (col + word.length <= 10) {
                            let match = true;
                            for (let i = 0; i < word.length; i++) {
                                if (grid[row][col + i] !== word[i]) {
                                    match = false;
                                    break;
                                }
                            }
                            if (match) {
                                const cell = document.querySelector(`[data-row="${row}"][data-col="${col}"]`);
                                cell.style.backgroundColor = "#ffeb3b";
                                setTimeout(() => cell.style.backgroundColor = "", 1000);
                                return;
                            }
                        }
                        if (row + word.length <= 9) {
                            let match = true;
                            for (let i = 0; i < word.length; i++) {
                                if (grid[row + i][col] !== word[i]) {
                                    match = false;
                                    break;
                                }
                            }
                            if (match) {
                                const cell = document.querySelector(`[data-row="${row}"][data-col="${col}"]`);
                                cell.style.backgroundColor = "#ffeb3b";
                                setTimeout(() => cell.style.backgroundColor = "", 1000);
                                return;
                            }
                        }
                        if (row + word.length <= 9 && col + word.length <= 10) {
                            let match = true;
                            for (let i = 0; i < word.length; i++) {
                                if (grid[row + i][col + i] !== word[i]) {
                                    match = false;
                                    break;
                                }
                            }
                            if (match) {
                                const cell = document.querySelector(`[data-row="${row}"][data-col="${col}"]`);
                                cell.style.backgroundColor = "#ffeb3b";
                                setTimeout(() => cell.style.backgroundColor = "", 1000);
                                return;
                            }
                        }
                    }
                }
            }

            function resetGame() {
                foundWords = {};
                const gridElement = document.getElementById("game-grid");
                gridElement.querySelectorAll("span").forEach(cell => {
                    cell.className = "";
                    cell.style.backgroundColor = "";
                    cell.textContent = grid[parseInt(cell.dataset.row)][parseInt(cell.dataset.col)];
                });
                generateGrid();
                populateWordList();
            }

            function checkSolution() {
                if (Object.keys(foundWords).length === words.length) advanceToNextLevel();
                else alert(`Found ${Object.keys(foundWords).length}/${words.length} words.`);
            }

            function advanceToNextLevel() {
                try {
                    const congratsModal = document.getElementById("congrats-modal");
                    const congratsMessage = document.getElementById("congrats-message");
                    const currentPuzzle = puzzles.find(p => p.id === currentThemeId);
                    congratsMessage.textContent = `Congratulations! ${currentPuzzle.theme} - Level ${currentLevel + 1} Completed!`;
                    congratsModal.classList.add("active");

                    const duration = 3 * 1000;
                    const end = Date.now() + duration;
                    (function frame() {
                        confetti({
                            particleCount: 3,
                            angle: 60,
                            spread: 55,
                            origin: { x: 0 },
                            colors: ['#ffff00', '#ff69b4', '#ff4040', '#9400d3'],
                            shapes: ['star', 'circle']
                        });
                        confetti({
                            particleCount: 3,
                            angle: 120,
                            spread: 55,
                            origin: { x: 1 },
                            colors: ['#ffff00', '#ff69b4', '#ff4040', '#9400d3'],
                            shapes: ['star', 'circle']
                        });
                        if (Date.now() < end) requestAnimationFrame(frame);
                    }());

                    totalLevelsCompleted++;
                    localStorage.setItem("totalLevelsCompleted", totalLevelsCompleted);
                    currentPuzzle.progress = Math.min(100, ((currentLevel + 1) / currentPuzzle.levels.length) * 100);
                    localStorage.setItem(`progress_theme_${currentThemeId}`, currentPuzzle.progress);

                    currentLevel++;
                    localStorage.setItem("currentLevel", currentLevel);
                    localStorage.setItem("currentThemeId", currentThemeId);

                    setTimeout(() => {
                        congratsModal.classList.remove("active");
                        confetti.reset();

                        if (currentLevel < currentPuzzle.levels.length) {
                            document.getElementById("game-title").textContent = `${currentPuzzle.theme} - Level ${currentLevel + 1}`;
                            initGame(currentPuzzle.levels[currentLevel].words);
                        } else {
                            const nextPuzzle = puzzles.find(p => p.id === currentThemeId + 1 && totalLevelsCompleted >= (p.id - 1) * 8);
                            if (nextPuzzle) {
                                currentThemeId = nextPuzzle.id;
                                currentLevel = 0;
                                localStorage.setItem("currentThemeId", currentThemeId);
                                localStorage.setItem("currentLevel", currentLevel);
                                document.getElementById("game-title").textContent = `${nextPuzzle.theme} - Level 1`;
                                initGame(nextPuzzle.levels[0].words);
                            } else {
                                localStorage.setItem("currentThemeId", currentThemeId);
                                localStorage.setItem("currentLevel", currentLevel);
                                document.getElementById("home-page").style.display = "block";
                                document.getElementById("game-container").style.display = "none";
                                updatePuzzleGrid();
                            }
                        }
                    }, 3000);
                } catch (e) {
                    console.error("Error in advanceToNextLevel:", e);
                    alert("Error advancing to next level. Returning to home.");
                    localStorage.setItem("currentThemeId", currentThemeId);
                    localStorage.setItem("currentLevel", currentLevel);
                    document.getElementById("home-page").style.display = "block";
                    document.getElementById("game-container").style.display = "none";
                    updatePuzzleGrid();
                }
            }
        } catch (e) {
            console.error("Error in initGame:", e);
        }
    }

    function updatePuzzleGrid() {
        const puzzleGrid = document.querySelector(".puzzle-grid");
        puzzleGrid.innerHTML = "";
        puzzles.forEach(puzzle => {
            puzzle.unlocked = totalLevelsCompleted >= (puzzle.id - 1) * 8;
            puzzleGrid.appendChild(createPuzzleCard(puzzle));
        });
    }

    document.addEventListener("DOMContentLoaded", () => {
        try {
            // Show loader for 3 seconds, then display homepage
            setTimeout(() => {
                document.getElementById("loader-screen").style.display = "none";
                document.getElementById("home-page").style.display = "block";
            }, 3000);

            updatePuzzleGrid();
            updateAudioButtons();

            let coins       = parseInt(localStorage.getItem("coins"))      || 0;
const claimBtn  = document.querySelector(".claim-btn");
const coinCounter = document.getElementById("coins");
const popupCard   = document.getElementById("popupCard");
const playAdBtn   = document.getElementById("playAdBtn");

const FIFTEEN_DAYS_MS = 15 * 24 * 60 * 60 * 1000;

claimBtn.addEventListener("click", () => {
  popupCard.style.display = "flex";
});

playAdBtn.addEventListener("click", () => {
  const now         = Date.now();
  const lastClaim   = parseInt(localStorage.getItem("lastClaim")) || 0;
  const timePassed  = now - lastClaim;

  if (timePassed >= FIFTEEN_DAYS_MS) {
    // Allow claim
    coins += 100;
    localStorage.setItem("coins", coins);
    localStorage.setItem("lastClaim", now);
    coinCounter.textContent = coins;
    alert("🎉 100 coins claimed!");

    popupCard.style.display = "none";
    // Redirect to the game/ad link
    window.location.href = "https://your-game-link.com";
  } else {
    // Calculate remaining days
    const msLeft      = FIFTEEN_DAYS_MS - timePassed;
    const daysLeft    = Math.ceil(msLeft / (24 * 60 * 60 * 1000));
    alert(`⚠️ You can claim coins again in ${daysLeft} day(s).`);
    popupCard.style.display = "none";
  }
});

function closePopup() {
  popupCard.style.display = "none";
}


            const adBanner = document.getElementById("ad-banner");
            adBanner.addEventListener("click", () => {
                if (confirm("Watch a short ad to earn 20 coins?")) {
                    setTimeout(() => {
                        coins += 20;
                        updateCoins();
                        alert("20 coins earned!");
                    }, 1000);
                } else {
                    alert("Ad skipped. No coins earned.");
                }
            });

            const menuBtn = document.getElementById("menu-btn");
            const settingsPopup = document.getElementById("settings-popup");
            const overlay = document.getElementById("overlay");
            const closeBtn = document.getElementById("close-btn");
            menuBtn.addEventListener("click", () => {
                settingsPopup.classList.add("active");
                overlay.classList.add("active");
            });
            closeBtn.addEventListener("click", () => {
                settingsPopup.classList.remove("active");
                overlay.classList.remove("active");
            });
            overlay.addEventListener("click", () => {
                settingsPopup.classList.remove("active");
                overlay.classList.remove("active");
            });

            document.getElementById("music-btn").addEventListener("click", toggleMusic);
            document.getElementById("sound-btn").addEventListener("click", toggleSound);
            document.getElementById("vibration-btn").addEventListener("click", toggleVibration);
            document.getElementById("highlight-style").addEventListener("change", (e) => {
                highlightStyle = e.target.value;
                localStorage.setItem("highlightStyle", highlightStyle);
            });

            const dailyRewardBtn = document.getElementById("daily-reward-btn");
            const dailyRewardPopup = document.getElementById("daily-reward-popup");
            const collectBtn = document.getElementById("collect-btn");
            const dailyRewardCloseBtn = document.getElementById("daily-reward-close-btn");
            dailyRewardBtn.addEventListener("click", () => {
                dailyRewardPopup.classList.add("active");
                overlay.classList.add("active");
            });
            collectBtn.addEventListener("click", () => {
                coins += 50;
                updateCoins();
                dailyRewardPopup.classList.remove("active");
                overlay.classList.remove("active");
                alert("50 coins collected!");
            });
            dailyRewardCloseBtn.addEventListener("click", () => {
                dailyRewardPopup.classList.remove("active");
                overlay.classList.remove("active");
            });
        } catch (e) {
        console.error("Error in DOMContentLoaded:", e);
    }
});